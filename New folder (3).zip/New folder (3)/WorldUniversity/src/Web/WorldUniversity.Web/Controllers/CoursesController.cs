﻿namespace WorldUniversity.Web.Web.Controllers
{
    using System.Linq;
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;
    using WorldUniversity.Services;
    using WorldUniversity.Services.Data;
    using WorldUniversity.Web.ViewModels.Enrollements;

    [Authorize(Roles = "Admin,Instructor")]
    public class CoursesController : Controller
    {
      
        private readonly IStudentsService studentsService;
        

        public CoursesController(
      IStudentsService studentsService
            )
        {

            this.studentsService = studentsService;

        }
        public IActionResult Index()
        {/*
            var courses = coursesService.GetAllCourses();
            return View(courses); */
            return View();
        }
        [Authorize]
        public IActionResult Enrollment()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Enrollment(CreateEnrollemntViewModel enrollment)
        {
            if (ModelState.IsValid)
            {
               
                return RedirectToAction(nameof(Index));
            }
            return View();
        }
        public IActionResult Details(string id)
        {
            return View();
        }

        public IActionResult Create()
        {
           return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(string t)
        {
            return View();
        }

        public IActionResult Edit(string id)
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, string course)
        {
           

            return View();
        }

        public IActionResult Delete(string id)
        {
            return View();
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            return View();
        }
    }
}