﻿namespace WorldUniversity.Data.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using WorldUniversity.Data.Common.Models;

    public class Course : BaseDeletableModel<string>, IAuditInfo
    {/*TODO READY*/
        public Course()
        {
            this.SemesterCourses = new HashSet<SemesterCourse>();
            this.Id = Guid.NewGuid().ToString();
        }

        public string Code { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string CategoryId { get; set; }

        public Category Category { get; set; }

        public virtual ICollection<SemesterCourse> SemesterCourses { get; set; }
        public string CreatedBy { get; set; }

        public string UpdatedBy { get; set; }
    }
}
