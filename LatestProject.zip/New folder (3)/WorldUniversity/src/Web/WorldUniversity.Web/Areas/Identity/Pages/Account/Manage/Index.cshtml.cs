﻿namespace WorldUniversity.Web.Areas.Identity.Pages.Account.Manage
{
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.RazorPages;
    using Microsoft.Extensions.Hosting;
    using WorldUniversity.Data.Models;

    public partial class IndexModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly IWebHostEnvironment environment;

        public IndexModel(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            IWebHostEnvironment environment)
        {
            this._userManager = userManager;
            this._signInManager = signInManager;
            this.environment = environment;
        }

        [TempData]
        public string StatusMessage { get; set; }

        [BindProperty]
        public InputModel Input { get; set; }

        public class InputModel
        {
            [Phone]
            [RegularExpression("^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$", ErrorMessage = "Your Phone Number Is Not Valid!")]
            [Display(Name = "Phone number")]
            public string PhoneNumber { get; set; }

            [Required(ErrorMessage = "The field is required!")]
            [MinLength(3, ErrorMessage = "The field requires more than 3 characters!")]
            [MaxLength(30, ErrorMessage = "The field must not be more than 30 characters!")]
            [DisplayName("First Name")]
            public string FirstName { get; set; }

            [Required(ErrorMessage = "The field is required!")]
            [MinLength(3, ErrorMessage = "The field requires more than 3 characters!")]
            [MaxLength(30, ErrorMessage = "The field must not be more than 30 characters!")]
            [DisplayName("Last Name")]
            public string LastName { get; set; }

            [EmailAddress]
            [Display(Name = "Email")]
            public string Email { get; set; }

            [MaxLength(50, ErrorMessage = "The field must not be more than 50 characters!")]
            public string Address { get; set; }

            [Display(Name = "User Photo")]
            public byte[] UserPhoto { get; set; }
        }

        private async Task LoadAsync(ApplicationUser user)
        {
            var phoneNumber = await this._userManager.GetPhoneNumberAsync(user);
            var firstName = user.FirstName;
            var lastName = user.LastName;
            var email = await this._userManager.GetEmailAsync(user);
            var address = user.Address;
            var userPhoto = user.UserPhoto;
            this.Input = new InputModel
            {
                Email = email,
                PhoneNumber = phoneNumber,
                FirstName = firstName,
                LastName = lastName,
                Address = address,
                UserPhoto = userPhoto,
            };
        }

        public async Task<IActionResult> OnGetAsync()
        {
            var user = await this._userManager.GetUserAsync(this.User);
            if (user == null)
            {
                return this.NotFound($"Unable to load user with ID '{this._userManager.GetUserId(this.User)}'.");
            }

            await this.LoadAsync(user);
            return this.Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = await this._userManager.GetUserAsync(this.User);
            if (user == null)
            {
                return this.NotFound($"Unable to load user with ID '{this._userManager.GetUserId(this.User)}'.");
            }

            if (!this.ModelState.IsValid)
            {
                await this.LoadAsync(user);
                return this.Page();
            }

            var phoneNumber = await this._userManager.GetPhoneNumberAsync(user);
            if (this.Input.PhoneNumber != phoneNumber)
            {
                var setPhoneResult = await this._userManager.SetPhoneNumberAsync(user, this.Input.PhoneNumber);
                if (!setPhoneResult.Succeeded)
                {
                    this.StatusMessage = "Unexpected error when trying to change your phone number.";
                    return this.RedirectToPage();
                }
            }

            var firstName = user.FirstName;
            if (this.Input.FirstName != firstName)
            {
                try
                {
                    user.FirstName = this.Input.FirstName;
                }
                catch (System.Exception)
                {
                    this.StatusMessage = "Unexpected error when trying to change First Name";
                    return this.RedirectToPage();
                }
            }

            var lastName = user.LastName;
            if (this.Input.LastName != lastName)
            {
                try
                {
                    user.LastName = this.Input.LastName;

                }
                catch (System.Exception)
                {
                    this.StatusMessage = "Unexpected error when trying to change Last Name";
                    return this.RedirectToPage();
                }
            }

            var address = user.Address;
            if (this.Input.Address != address)
            {
                try
                {
                    user.Address = this.Input.Address;
                }
                catch (System.Exception)
                {
                    this.StatusMessage = "Unexpected error when trying to change Address";
                    return this.RedirectToPage();
                }
            }

            if (this.Request.Form.Files.Count > 0)
            {
                IFormFile file = this.Request.Form.Files.FirstOrDefault();
                using (var dataStream = new MemoryStream())
                {
                    await file.CopyToAsync(dataStream);
                    user.UserPhoto = dataStream.ToArray();
                }

            }

            await this._userManager.UpdateAsync(user);
            await this._signInManager.RefreshSignInAsync(user);
            this.StatusMessage = "Your profile has been updated";
            return this.RedirectToPage();
        }
    }
}
