﻿namespace WorldUniversity.Data.Seeding
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.Identity;
    using WorldUniversity.Common;
    using WorldUniversity.Data.Models;

    public class UsersSeeder:ISeeder
    {
        private readonly UserManager<ApplicationUser> userManager;

        public UsersSeeder(UserManager<ApplicationUser> userManager)
        {
            this.userManager = userManager;
        }

        public async Task SeedAsync(ApplicationDbContext dbContext, IServiceProvider serviceProvider)
        {

            var user = new ApplicationUser();
            user.FirstName = "Ivan";
            user.LastName = "Ivanov";
            user.UserName = "user@wumail.bg";
            user.Email = "user@wumail.bg";

            await this.userManager.CreateAsync(user, "12345678");
            await this.userManager.AddToRoleAsync(user, GlobalConstants.StudentRoleName);
            user.EmailConfirmed = true;

            var instructor = new ApplicationUser();
            instructor.FirstName = "Ivan";
            instructor.LastName = "Instructor";
            instructor.UserName = "instructor@wumail.bg";
            instructor.Email = "instructor@wumail.bg";
            await this.userManager.CreateAsync(instructor, "12345678");
            await this.userManager.AddToRoleAsync(instructor, GlobalConstants.InstructorRoleName);
            instructor.EmailConfirmed = true;

            var administrator = new ApplicationUser();
            administrator.FirstName = "Ivan";
            administrator.LastName = "administrator";
            administrator.UserName = "administrator@wumail.bg";
            administrator.Email = "administrator@wumail.bg";
            administrator.EmailConfirmed = true;
            await this.userManager.CreateAsync(administrator, "12345678");
            await this.userManager.AddToRoleAsync(administrator, GlobalConstants.AdministratorRoleName);
 
        }
    }
}
