﻿var usersInformationButton = document.getElementById("usersInformationButton");
var instructorsInformationButton = document.getElementById("instructorsInformationButton");
var administratorsInformationButton = document.getElementById("administratorsInformationButton");

function usersInformation() {
    removeAllActiveClass();
    usersInformationButton.classList.add("active");
}
function instructorsInformation() {
    removeAllActiveClass();
    instructorsInformationButton.classList.add("active");
}
function administratorsInformation() {
    removeAllActiveClass();
    administratorsInformationButton.classList.add("active");
}
function removeAllActiveClass() {
    usersInformationButton.classList.remove("active");
    instructorsInformationButton.classList.remove("active");
    administratorsInformationButton.classList.remove("active");
}