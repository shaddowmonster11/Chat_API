﻿namespace WorldUniversity.Web.ViewModels.Instructors
{
    using System.Collections.Generic;

    using WorldUniversity.Data.Models;

    public class InstructorViewModel
    {
        public string Id { get; set; }

        public string Email { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string CreatedOn { get; set; }

        public ICollection<SemesterCourse> Courses { get; set; }

        public string Role { get; set; }
    }
}
