﻿namespace WorldUniversity.Services.Mapping
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapTo<T>
    {
    }
}
