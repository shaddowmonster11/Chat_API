﻿function ReCaptcha(apiKey, form) {
    grecaptcha.ready(function() {
        grecaptcha.execute(apiKey, { action: form }).then(
            function(token) {
                document.getElementById("RecaptchaValue").value = token;
            });
    });
}