﻿namespace WorldUniversity.Web.ViewModels.Exams
{
    using System.Collections.Generic;

    using WorldUniversity.Data.Models;
    using WorldUniversity.Data.Models.ExamModels;

    public class ExamAssignmentViewModel
    {
        public int Id { get; set; }
        public string CourseId { get; set; }
        public int ExamId { get; set; }
        public Course Course { get; set; }
        public Exam Exam { get; set; }
        public ICollection<ApplicationUser> Students { get; set; }
    }
}
