﻿window.onload = function () {
    table = $('#example').DataTable({
        paging: true
    });
    table = $('#exampleOne').DataTable({
        paging: true
    });
    table = $('#exampleTwo').DataTable({
        paging: true
    });

}

function PrintOnlyTable() {
    table.destroy();
    $('#example').dataTable({
        "pageLength": -1
    });
    var HTML = $("body");
    HTML.html($("#example"));
    window.print();
    location.reload();
}