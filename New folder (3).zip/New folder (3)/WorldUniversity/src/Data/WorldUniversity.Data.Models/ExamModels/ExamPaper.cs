﻿namespace WorldUniversity.Data.Models.ExamModels
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class ExamPaper
    {
        public ExamPaper()
        {
            this.Id = Guid.NewGuid().ToString();
        }

        public string Id { get; set; }

        public string RegistrationId { get; set; }
        public string ExamQuestionId { get; set; }
        public string ChoiceId { get; set; }
        public string Answer { get; set; }
        public double MarkScore { get; set; }
        public  Choice Choice { get; set; }
        public  Registration Registration { get; set; }
        public  ExamQuestion ExamQuestion { get; set; }
    }
}
