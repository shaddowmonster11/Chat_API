﻿//functionality of LoadMore btn on course page
$(document).ready(function () {
    $("#load-btn").on("click", function (e) {
        e.preventDefault();

        let url = "/Home/CourseCardPartial/";
        $.ajax({
            url: url,
            cache: false,
            type: "Get",
            success: function (data) {
                if (data.length !== 0) {
                    $(data).insertBefore("#load-btn").hide().fadeIn(2000);
                    document.querySelector(`#load-btn`).scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
                }
            }
        });
    });
});


//https://hamidmosalla.com/2015/09/20/implementing-load-more-button-using-asp-net-mvc-and-jquery-part-one/
//https://hamidmosalla.com/2015/09/25/implementing-load-more-button-using-asp-net-mvc-and-jquery-part-two/