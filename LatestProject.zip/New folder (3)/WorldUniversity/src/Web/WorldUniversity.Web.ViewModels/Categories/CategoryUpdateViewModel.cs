﻿namespace WorldUniversity.Web.ViewModels.Categories
{
    using WorldUniversity.Data.Models;
    using WorldUniversity.Services.Mapping;

    public class CategoryUpdateViewModel: IMapFrom<Category>
    {
        public string Id { get; set; }

        public string Title { get; set; }

        public string CategoryDescription { get; set; }
    }
}
