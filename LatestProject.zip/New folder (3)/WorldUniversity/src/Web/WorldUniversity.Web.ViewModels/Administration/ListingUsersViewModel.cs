﻿using System;
using System.Collections.Generic;
using System.Text;
using WorldUniversity.Data.Models;

namespace WorldUniversity.Web.ViewModels.Administration
{
    public class ListingUsersViewModel
    {
        public ICollection<ApplicationUser> Students { get; set; }

        public ICollection<ApplicationUser> Instructors { get; set; }

        public ICollection<ApplicationUser> Administrators { get; set; }
    }
}
