﻿namespace WorldUniversity.Data.Seeding
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    using WorldUniversity.Data.Models;

    public class CoursesSeeder : ISeeder
    {
        public async Task SeedAsync(ApplicationDbContext dbContext, IServiceProvider serviceProvider)
        {
            if (!dbContext.Courses.Any())
            {
                var courses = new Course[]
                 {
                    new Course
                    {
                        Title = "Basic Algoritms",
                        Credits = 3,
                    },
                    new Course
                    {
                        Title = "VSM",
                        Credits = 4,
                    },
                    new Course
                    {
                        Title = "Html",
                        Credits = 3,
                    },
                 };

                foreach (var course in courses)
                {
                    await dbContext.AddAsync(course);
                }
            }
        }
    }
}
