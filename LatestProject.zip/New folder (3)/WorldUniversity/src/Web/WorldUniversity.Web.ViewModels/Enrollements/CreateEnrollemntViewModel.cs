﻿namespace WorldUniversity.Web.ViewModels.Enrollements
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    using WorldUniversity.Web.ViewModels.Students;

    public class CreateEnrollemntViewModel
    {   
        public string CourseTitle { get; set; }
        [Display(Name = "Student")]
        public string StudentId { get; set; }
        public IEnumerable<StudentViewModel> Students { get; set; }
        [Display(Name = "Course")]
        public string CourseId { get; set; }
      //  public IEnumerable<CourseViewModel> Courses { get; set; }
    }
}
