﻿namespace WorldUniversity.Web.Controllers
{
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;
    using WorldUniversity.Services;
    using WorldUniversity.Services.Data.Exams;
    using WorldUniversity.Web.ViewModels.Exams;
    using WorldUniversity.Web.ViewModels.Questions;

    public class ExamsController : Controller
    {
        private readonly IExamsService examsService;


        public ExamsController(IExamsService examsService
           )
        {
            this.examsService = examsService;
            
        }
        public IActionResult Index()
        {
           /* var exams = examsService.GetAllExams();*/
            return View();
        }
        public IActionResult CreateExam()
        {

           /* var course = new CreateExamInputModel
            {
                Courses = courses,
            };*/
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateExam(CreateExamInputModel exam)
        {
         /*   if (examsService.ExamExists(exam.Title, exam.Date) && !examsService.ExamIsArchieved(exam.Title))
            {
                ViewBag.ErrorTitle = "Dublicated Name";
                ViewBag.ErrorMessage = $"Exam with Title {exam.Title} already exists";
                return View("Error");

            }*/
            if (ModelState.IsValid)
            {
                await examsService.CreateExam(exam);
                return RedirectToAction("Index","ExamSessions");
            }
          /*  var allExams = examsService.GetAllExams();
            var viewModel = examsService.PopulateAssignedExamData(exam.CourseId, allExams);*/
            return View(exam);
        }
        public IActionResult ExamDetails(int id)
        {
          /*  var exam = examsService.GetExamAllDetails(id);         */
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ArchiveExam(int id)
        {
        //  await examsService.ArchieveExam(id);
            return RedirectToAction(nameof(Index));
        }
        public IActionResult EditExam(int id)
        {/*
            var exam = examsService.GetExamDetails(id);
            if (exam == null)
            {
                return NotFound();
            }*/
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditExam(int id, ExamDetailsViewModel exam)
        {
            if (id != exam.ExamId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                  //  await examsService.UpdateExam(exam);
                }
                catch (DbUpdateConcurrencyException)
                {
                  /*  if (!examsService.ExamExists(exam.Title, exam.Date))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }*/
                }
                return RedirectToAction("ExamDetails", "Exams", new { id = exam.ExamId });
            }
            return View(exam);
        }

    }

}
