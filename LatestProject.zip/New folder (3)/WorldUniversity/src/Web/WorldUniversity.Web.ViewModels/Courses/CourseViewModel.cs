﻿namespace WorldUniversity.Web.ViewModels.Courses
{
    using WorldUniversity.Data.Models;
    using WorldUniversity.Services.Mapping;

    public class CourseViewModel : IMapFrom<Course>
    {
        public string Name { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }

        public string Category { get; set; }
    }
}
