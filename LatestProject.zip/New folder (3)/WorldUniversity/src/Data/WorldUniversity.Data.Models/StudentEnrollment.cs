﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorldUniversity.Data.Models
{
    public class StudentEnrollment
    {
        public string StudentId { get; set; }
        public ApplicationUser Student { get; set; }

        public string RegistrationId { get; set; }
        public Enrollment Registration { get; set; }
    }
}
