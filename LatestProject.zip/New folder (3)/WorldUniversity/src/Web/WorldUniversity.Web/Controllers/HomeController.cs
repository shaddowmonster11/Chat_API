﻿namespace WorldUniversity.Web.Controllers
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using System.Diagnostics;
    using System.Threading.Tasks;
    using WorldUniversity.Services.Data;
    using WorldUniversity.Services.Messaging;
    using WorldUniversity.Web.ViewModels.Error;
    using WorldUniversity.Web.ViewModels.Home;

    public class HomeController : Controller
    {
        private readonly IContactService contactService;
        private readonly IMailHelper mailHelper;

        public HomeController(
            IContactService contactService,
            IMailHelper mailHelper)
        {
            this.contactService = contactService;
            this.mailHelper = mailHelper;
        }

        [AllowAnonymous]
        public ActionResult About()
        {
            return this.View();
        }
        [AllowAnonymous]
        public IActionResult AboutReadMore()
        {
            return this.View();
        }

        [AllowAnonymous]
        public IActionResult Index()
        {
            return this.View();
        }

        [AllowAnonymous]
        public IActionResult Courses()
        {
            return this.View();
        }

        [AllowAnonymous]
        public IActionResult Privacy()
        {
            return this.View();
        }

        [AllowAnonymous]
        public IActionResult TermsAndConditions()
        {
            return this.View();
        }   

        [AllowAnonymous]
        public IActionResult FAQ()
        {
            return this.View();
        }

        [AllowAnonymous]
        public IActionResult Contact()
        {
            return this.View();
        }
        [AllowAnonymous]
        public IActionResult HeaderPartial()
        {
            return PartialView();
        }
        [AllowAnonymous]
        public IActionResult CourseCardPartial()
        {
            return PartialView("_CourseCardPartial");
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Contact(ContactFormInputModel input)
        {
            if (!this.ModelState.IsValid)
            {
                return this.View(input);
            }

            await this.contactService.CreateAsync(input.Name, input.Email, input.Title, input.Content);

            await this.mailHelper.SendContactFormAsync(input.Email, input.Name, input.Title, input.Content);
            return this.RedirectToAction("Index");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return this.View(
                new ErrorViewModel { RequestId = Activity.Current?.Id ?? this.HttpContext.TraceIdentifier });
        }
    }
}
