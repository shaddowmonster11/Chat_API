﻿namespace WorldUniversity.Services.Data
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using WorldUniversity.Data.Common.Repositories;
    using WorldUniversity.Data.Models;
    using WorldUniversity.Web.ViewModels.Courses;

    public class CoursesService : ICourseService
    {
        private readonly IDeletableEntityRepository<Course> courseRepository;

        public CoursesService(IDeletableEntityRepository<Course> courseRepository)
        {
            this.courseRepository = courseRepository;
        }

        public async Task CreateAsync(CourseInputModel input)
        {
            var course = new Course
            {
                Name = input.Name,
                Description = input.Description,
                CategoryId = input.CategoryId,
                Code = input.Code,
            };

            await this.courseRepository.AddAsync(course);
            await this.courseRepository.SaveChangesAsync();
        }

        public Task DeleteCourse(string id)
        {
            throw new NotImplementedException();
        }

        public ICollection<CourseViewModel> GetAllCourses()
        {
            throw new NotImplementedException();
        }

        public Task UpdateCourse(int Id, string title, int credits, int? departmentId)
        {
            throw new NotImplementedException();
        }
    }
}
