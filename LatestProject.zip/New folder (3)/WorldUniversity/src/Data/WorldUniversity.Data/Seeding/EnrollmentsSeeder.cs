﻿namespace WorldUniversity.Data.Seeding
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    using Microsoft.EntityFrameworkCore;
    using WorldUniversity.Data.Models;

    public class EnrollmentsSeeder : ISeeder
    {
        public async Task SeedAsync(ApplicationDbContext dbContext, IServiceProvider serviceProvider)
        {
            //if (!dbContext.Enrollments.Any())
            //{
            //    var students = await dbContext.Users.ToListAsync();
            //    var courses = await dbContext.Courses.ToListAsync();
            //    var enrollments = new Enrollment[]
            //  {
            //  new Enrollment
            //  {
            //      StudentId = students.Single(s => s.LastName == "Ivanov").Id,
            //      Student = students.Single(s => s.LastName == "Ivanov"),
            //  },
            //  new Enrollment
            //  {
            //      StudentId = students.Single(s => s.LastName == "Mutafov").Id,

            //      Student = students.Single(s => s.LastName == "Mutafov"),
            //  },
            //  new Enrollment
            //  {
            //      StudentId = students.Single(s => s.LastName == "Stracimirov").Id,
            //      Grade = "A",
            //      Course = courses.Single(c => c.Title == "Basic Algoritms"),
            //      Student = students.Single(s => s.LastName == "Stracimirov"),
            //  },
            //  new Enrollment
            //  {
            //      StudentId = students.Single(s => s.LastName == "Stoqnova").Id,
            //      Grade = "A",
            //      Course = courses.Single(c => c.Title == "Html"),
            //      Student = students.Single(s => s.LastName == "Stoqnova"),
            //  },
            //  new Enrollment
            //  {
            //      StudentId = students.Single(s => s.LastName == "Hristov").Id,
            //      Grade = "A",
            //      Course = courses.Single(c => c.Title == "Html"),
            //      Student = students.Single(s => s.LastName == "Hristov"),
            //  },
            //  new Enrollment
            //  {
            //      StudentId = students.Single(s => s.LastName == "Petrov").Id,
            //      Grade = "A",
            //      Course = courses.Single(c => c.Title == "VSM"),
            //      Student = students.Single(s => s.LastName == "Petrov"),
            //  },

            //  };
            //    foreach (var enrollement in enrollments)
            //    {
            //      await dbContext.Enrollments.AddAsync(enrollement);   
            //    }

            //}
        }
    }
}
