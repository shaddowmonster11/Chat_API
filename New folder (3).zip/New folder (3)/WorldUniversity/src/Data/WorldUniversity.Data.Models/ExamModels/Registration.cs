﻿namespace WorldUniversity.Data.Models.ExamModels
{
    using System;
    using System.Collections.Generic;

    public class Registration
    {
        public Registration()
        {
            this.Id = Guid.NewGuid().ToString();
            this.ExamPapers = new HashSet<ExamPaper>();
        }

        public string Id { get; set; }

        public string StudentId { get; set; }

        public DateTime RegistrationDate { get; set; }

        public string Token { get; set; }

        public string ExamId { get; set; }

        public ApplicationUser Student { get; set; }

        public Exam Exam { get; set; }

        public DateTime TokenExpireTime { get; set; }

        public ICollection<ExamPaper> ExamPapers { get; set; }
    }
}
