﻿
namespace WorldUniversity.Data.Models.ExamModels
{
    using System;
    using System.Collections.Generic;

    public class Question
    {
        public Question()
        {
            this.Id = Guid.NewGuid().ToString();
            ExamQuestions = new HashSet<ExamQuestion>();
            Choices = new HashSet<Choice>();
        }
      
        public string Id { get; set; }
        public string QuestionType { get; set; }
        public string QuestionContent { get; set; }
        public string QuestionId { get; set; }
        public double Points { get; set; }
        public bool? IsActive { get; set; }
        public  ICollection<Choice> Choices { get; set; }
        public  ICollection<ExamQuestion> ExamQuestions { get; set; }

    }
}
