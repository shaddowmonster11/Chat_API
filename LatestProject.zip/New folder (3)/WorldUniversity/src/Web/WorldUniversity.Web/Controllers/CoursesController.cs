﻿namespace WorldUniversity.Web.Web.Controllers
{
    using System.Linq;
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;
    using WorldUniversity.Common;
    using WorldUniversity.Data.Models;
    using WorldUniversity.Services;
    using WorldUniversity.Services.Data;
    using WorldUniversity.Web.Infrastructure.Attributes;
    using WorldUniversity.Web.ViewModels.Courses;
    using WorldUniversity.Web.ViewModels.Enrollements;

    [AuthorizeRoles(GlobalConstants.AdministratorRoleName)]
    public class CoursesController : Controller
    {
        private readonly ICourseService courseService;
        private readonly ICategoriesService categoriesService;

        public CoursesController(
            ICourseService courseService,
            ICategoriesService categoriesService)
        {
            this.courseService = courseService;
            this.categoriesService = categoriesService;
        }

        public IActionResult Index()
        {/*
            var courses = coursesService.GetAllCourses();
            return View(courses); */
            return this.View();
        }

        public IActionResult Create()
        {
            var categories = this.categoriesService.GetAll<CategoryDropDownViewModel>();

            var viewModel = new CourseInputModel
            {
                Categories = categories,
            };

            return this.View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CourseInputModel course)
        {
            if (this.ModelState.IsValid)
            {
                await this.courseService.CreateAsync(course);
                return this.RedirectToAction("Index");
            }

            return this.View(course);
        }

        [Authorize]
        public IActionResult Enrollment()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Enrollment(CreateEnrollemntViewModel enrollment)
        {
            if (ModelState.IsValid)
            {

                return RedirectToAction(nameof(Index));
            }
            return View();
        }
        public IActionResult Details(string id)
        {
            return View();
        }

        public IActionResult Edit(string id)
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, string course)
        {


            return View();
        }
    }
}