﻿namespace WorldUniversity.Services.Data
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    using WorldUniversity.Web.ViewModels.Students;

    public interface IStudentsService
    {
        StudentViewModel GetStudentDetails(string id);
        ICollection<StudentViewModel> GetAll();
        Task DeleteStudent(string userId);
        bool IsEmailInUse(string email);
        bool IsUsernameInUse(string username);
    }
}