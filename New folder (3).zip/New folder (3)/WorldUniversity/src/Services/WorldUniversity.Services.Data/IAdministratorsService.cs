﻿namespace WorldUniversity.Services.Data
{
    using System.Threading.Tasks;

    public interface IAdministratorsService
    {
        Task DeleteAdministrator(string userId);
    }
}
