﻿namespace WorldUniversity.Common;

public static class GlobalConstants
{
    public const string SystemName = "WorldUniversity";

    public const string AdministratorRoleName = "Administrator";
    public const string InstructorRoleName = "Instructor";
    public const string StudentRoleName = "Student";
}
