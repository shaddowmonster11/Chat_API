﻿namespace WorldUniversity.Web.ViewModels.Exams
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    using WorldUniversity.Web.ViewModels.Questions;

    public class ExamViewModel
    {
        public string Id { get; set; }
        public string Title { get; set; }

        public string Description { get; set; }
        public int DurationInMinutes { get; set; }
    }
}
