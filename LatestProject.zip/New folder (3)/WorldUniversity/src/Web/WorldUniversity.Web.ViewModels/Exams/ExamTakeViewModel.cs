﻿namespace WorldUniversity.Web.ViewModels.Exams
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class ExamTakeViewModel
    {

    }
}
