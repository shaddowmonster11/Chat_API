﻿namespace WorldUniversity.Data.Models
{
    using System;
    using System.Collections.Generic;

    using WorldUniversity.Data.Common.Models;

    public class Course : IDeletableEntity,IAuditInfo
    {
        public Course()
        {
            ExamAssignments = new HashSet<ExamAssignment>();
            Enrollments = new HashSet<Enrollment>();
            Id = Guid.NewGuid().ToString();
        }
        public string Id { get; set; }

        public string Title { get; set; }

        public int Credits { get; set; }

        public ICollection<Enrollment> Enrollments { get; set; }
        public string InstructorId { get; set; }
        public ApplicationUser Instructor { get; set; }
        public ICollection<ExamAssignment> ExamAssignments { get; set; }

        public bool IsDeleted { get; set; }
        public DateTime? DeletedOn { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? ModifiedOn { get; set; }
    }
}