﻿namespace WorldUniversity.Services.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    using Microsoft.EntityFrameworkCore;
    using WorldUniversity.Data;
    using WorldUniversity.Data.Common.Repositories;
    using WorldUniversity.Data.Models;
    using WorldUniversity.Services.Mapping;
    using WorldUniversity.Web.ViewModels.Categories;

    public class CategoriesService : ICategoriesService
    {
        private readonly IDeletableEntityRepository<Category> categoryRepository;

        public CategoriesService(IDeletableEntityRepository<Category> categoryRepository)
        {
            this.categoryRepository = categoryRepository;
        }

        public async Task CreateAsync(CategoryInputModel input)
        {
            var category = new Category
            {
                Title = input.Title,
                CategoryDescription = input.CategoryDescription,
            };
            await this.categoryRepository.AddAsync(category);
            await this.categoryRepository.SaveChangesAsync();
        }

        public async Task DeleteAsync(string id)
        {
            var category = await this.categoryRepository
                .All()
                .FirstOrDefaultAsync(x => x.Id == id);

            this.categoryRepository.Delete(category);
            await this.categoryRepository.SaveChangesAsync();
        }

        public IEnumerable<T> GetAll<T>()
        {
            var categories = this.categoryRepository
              .All()
              .To<T>()
              .ToList();

            return categories;
        }

        public async Task<T> GetByIdAsync<T>(string id)
        {
            var category = await this.categoryRepository
                .All()
                .Where(x => x.Id == id)
                .To<T>()
                .FirstOrDefaultAsync();

            return category;
        }

        public async Task UpdateAsync(CategoryUpdateInputModel input)
        {
            var categories = await this.categoryRepository
                .All()
                .FirstOrDefaultAsync(x => x.Id == input.Id);

            categories.Title = input.Title;
            categories.CategoryDescription = input.CategoryDescription;

            await this.categoryRepository.SaveChangesAsync();
        }
    }
}
