﻿namespace WorldUniversity.Data.Models.ExamModels
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class ExamQuestion
    {
        public ExamQuestion()
        {
            this.Id = Guid.NewGuid().ToString();
            ExamPapers = new HashSet<ExamPaper>();
        }

        public string Id { get; set; }
        public string ExamId { get; set; }
        public string QuestionId { get; set; }
        public int QuestionNumber { get; set; }
        public bool? IsActive { get; set; }
        public  Question Question { get; set; }
        public  Exam Exam { get; set; }
        public  ICollection<ExamPaper> ExamPapers { get; set; }
    }
}
