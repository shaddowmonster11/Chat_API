﻿namespace WorldUniversity.Services.Data.Exams
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    using WorldUniversity.Data.Models;
    using WorldUniversity.Web.ViewModels.Exams;

    public interface IExamAssignmentsService
    {
        Task Create(int examId, string courseId);
        ICollection<ExamAssignmentViewModel> GetAllExamAssignments();
        bool ExamAssignmentExist(int examId, string courseId);
        ExamAssignmentViewModel GetExamAssignmentByExamId(int examId);
        ICollection<ExamAssignment> GetAllExamAssignmentsByCourseId(string courseId);
        Task AddExamAssigmentToStudent(string userId, string courseId);
    }
}
