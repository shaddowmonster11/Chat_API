﻿namespace WorldUniversity.Web.ViewModels.Courses
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using WorldUniversity.Data.Models;
    using WorldUniversity.Services.Mapping;

    public class CourseInputModel : IMapTo<Course>
    {
        [Required(ErrorMessage = "The field is required!")]
        public string Name { get; set; }

        public string Code { get; set; }

        [MaxLength(200, ErrorMessage = "The field must not be more than 200 characters!")]
        public string Description { get; set; }

        public string CategoryId { get; set; }

        public IEnumerable<CategoryDropDownViewModel> Categories { get; set; }
    }
}
//public string Id { get; set; }

//public string Title { get; set; }

//public string Description { get; set; }

//public string CategoryId { get; set; }

//public Category Category { get; set; }

//public virtual ICollection<Cycle> Cycles { get; set; }


//public ICollection<Enrollment> Enrollments { get; set; }
//public string InstructorId { get; set; }

//public ApplicationUser Instructor { get; set; }

//public ICollection<ExamAssignment> ExamAssignments { get; set; }

//public bool IsDeleted { get; set; }

//public DateTime? DeletedOn { get; set; }
