﻿namespace WorldUniversity.Services.Data
{
    using WorldUniversity.Web.ViewModels;

    public interface IHomeService
    {
        //EnrollmentDateGroup GetGeneralInformation();
    }
}
