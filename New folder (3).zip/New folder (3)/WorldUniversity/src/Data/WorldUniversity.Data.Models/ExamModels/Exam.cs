﻿namespace WorldUniversity.Data.Models.ExamModels
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class Exam
    {
        public Exam()
        {
            this.Id = Guid.NewGuid().ToString();
            ExamQuestions = new HashSet<ExamQuestion>();
            Registrations = new HashSet<Registration>();
        }
 
        public string Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool? IsActive { get; set; }
        public int DurationInMinutes { get; set; }
        public bool IsArchived { get; set; }
        public  ICollection<Registration> Registrations { get; set; }
        public  ICollection<ExamQuestion> ExamQuestions { get; set; }
    }
}
