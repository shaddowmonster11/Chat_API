﻿namespace WorldUniversity.Web.Controllers
{
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;
    using WorldUniversity.Common;
    using WorldUniversity.Data;
    using WorldUniversity.Services.Data;
    using WorldUniversity.Web.Infrastructure.Attributes;

    [AuthorizeRoles(new[] { GlobalConstants.AdministratorRoleName, GlobalConstants.InstructorRoleName })]
    public class StudentsController : Controller
    {
        private readonly IStudentsService studentService;
        private readonly ApplicationDbContext db;

        public StudentsController(IStudentsService studentService,ApplicationDbContext db)
        {
            this.studentService = studentService;
            this.db = db;
        }

        public async Task<IActionResult> Index()
        {
            var studentViewModel = this.studentService.GetAll();
            //return View(await PaginatedList<StudentViewModel>
            //    .CreateAsync(studentViewModel.AsNoTracking(), pageNumber ?? 1));
            return View(studentViewModel);
        }

       

        public IActionResult Details(string id)
        {
            var studentViewModel = this.studentService.GetStudentDetails(id);
            if (studentViewModel == null)
            {
                return NotFound();
            }

            return View(studentViewModel);
        }

        public async Task<IActionResult> Delete(string id)
        {//TODO FIX THE DELETE
            await this.studentService.DeleteStudent(id);
            return View("");
        }  

    }
}
