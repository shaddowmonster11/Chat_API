﻿
namespace WorldUniversity.Data.Models
{
    using System;

    using WorldUniversity.Data.Common.Models;

    public class Enrollment : BaseDeletableModel<string>, IAuditInfo
    {
        public Enrollment()
        {
            this.Id = Guid.NewGuid().ToString();
        }

        public string SemesterCourseId { get; set; }

        public SemesterCourse SemesterCourses { get; set; }

        public string StudentId { get; set; }

        public ApplicationUser Student { get; set; }
    }
}
