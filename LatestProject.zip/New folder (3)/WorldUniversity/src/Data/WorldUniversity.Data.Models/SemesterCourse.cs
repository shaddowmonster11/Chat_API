﻿namespace WorldUniversity.Data.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    using WorldUniversity.Data.Common.Models;

    public class SemesterCourse : BaseDeletableModel<string>, IAuditInfo
    {
        public SemesterCourse()
        {
            this.Id = Guid.NewGuid().ToString();
            //this.Exams = new HashSet<Exam>();
            this.Enrollments = new HashSet<Enrollment>();
        }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string CourseId { get; set; }

        public Course Course { get; set; }

        public string InstructorId { get; set; }

        public ApplicationUser Instructor { get; set; }

        public string CreatedBy { get; set; }

        public string UpdatedBy { get; set; }

        public IEnumerable<Enrollment> Enrollments { get; set; }

        //public IEnumerable<Exam> Exams { get; set; }

    }
}
