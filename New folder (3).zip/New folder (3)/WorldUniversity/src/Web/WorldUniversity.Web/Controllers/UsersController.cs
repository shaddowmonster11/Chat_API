﻿namespace WorldUniversity.Web.Controllers
{
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.WebUtilities;
    using Microsoft.EntityFrameworkCore;
    using System.Linq;
    using System.Text;
    using System.Text.Encodings.Web;
    using System.Threading.Tasks;
    using WorldUniversity.Common;
    using WorldUniversity.Data;
    using WorldUniversity.Data.Models;
    using WorldUniversity.Services.Data;
    using WorldUniversity.Services.Messaging;
    using WorldUniversity.Web.Infrastructure.Attributes;
    using WorldUniversity.Web.ViewModels.Users;

    [AuthorizeRoles(new[] { GlobalConstants.AdministratorRoleName, GlobalConstants.InstructorRoleName })]
    public class UsersController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly IMailHelper mailHelper;
        private readonly ApplicationDbContext context;
        private readonly IStudentsService studentsService;
        private readonly IAdministratorsService administratorsService;
        private readonly IInstructorsService instructorsService;

        public UsersController(
            UserManager<ApplicationUser> userManager,
            IMailHelper mailHelper,
            ApplicationDbContext context,
            IStudentsService studentsService,
            IAdministratorsService administratorsService,
            IInstructorsService instructorsService
            )
        {
            this.userManager = userManager;
            this.mailHelper = mailHelper;
            this.context = context;
            this.studentsService = studentsService;
            this.administratorsService = administratorsService;
            this.instructorsService = instructorsService;
        }

        public IActionResult Create()
        {
            return this.View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(UserCreateInputModel input)
        {
            if (!this.ModelState.IsValid)
            {
                return this.View(input);
            }

            var user = await this.userManager.GetUserAsync(this.User);

            var newUser = new ApplicationUser
            {
                FirstName = input.FirstName,
                LastName = input.LastName,
                UserName = input.Username,
                Email = input.Email,
            };
            var result = await this.userManager.CreateAsync(newUser, input.Password);
            if (result.Succeeded)
            {
                var code = await this.userManager.GenerateEmailConfirmationTokenAsync(newUser);
                code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(code));

                var callbackUrl = this.Url.Page(
                    "/Account/ConfirmEmail",
                    pageHandler: null,
                    values: new { area = "Identity", userId = newUser.Id, code = code },
                    protocol: this.Request.Scheme);

                await this.mailHelper.SendFromIdentityAsync(
                    input.Email,
                    "Confirm your registration",
                    $"{newUser.FirstName} {newUser.LastName}",
                    "You are receiving this email because we received a registration confirmation request.",
                    HtmlEncoder.Default.Encode(callbackUrl),
                    "If you did not request a registration confirmation, no further action is needed.");
            }

            switch (input.Role)
            {
                case GlobalConstants.StudentRoleName:
                    await this.userManager.AddToRoleAsync(newUser, GlobalConstants.StudentRoleName);
                    break;
                case GlobalConstants.InstructorRoleName:
                    await this.userManager.AddToRoleAsync(newUser, GlobalConstants.InstructorRoleName);
                    break;
                case GlobalConstants.AdministratorRoleName:
                    await this.userManager.AddToRoleAsync(newUser, GlobalConstants.AdministratorRoleName);
                    break;
            }

            return this.RedirectToAction("ListRoles", "Administration");
        }


        [HttpPost]
        public async Task<IActionResult> EditRole(string userId, string role)
        {
            var user = await this.userManager.Users.FirstOrDefaultAsync(u => u.Id == userId);

            var userRoles = await this.userManager.GetRolesAsync(user);

            switch (role)
            {
                case GlobalConstants.StudentRoleName:
                    await this.userManager.RemoveFromRolesAsync(user, userRoles);
                    await this.userManager.AddToRoleAsync(user, GlobalConstants.StudentRoleName);
                    break;
                case GlobalConstants.InstructorRoleName:
                    await this.userManager.RemoveFromRolesAsync(user, userRoles);
                    await this.userManager.AddToRoleAsync(user, GlobalConstants.InstructorRoleName);
                    break;
                case GlobalConstants.AdministratorRoleName:
                    await this.userManager.RemoveFromRolesAsync(user, userRoles);
                    await this.userManager.AddToRoleAsync(user, GlobalConstants.AdministratorRoleName);
                    break;
            }

            return this.RedirectToAction("ListRoles", "Administration");
        }

        public async Task<IActionResult> DeleteUser(string role, string userId)
        {

            if (role == GlobalConstants.StudentRoleName)
            {
                await this.studentsService.DeleteStudent(userId);
            }
            else if (role == GlobalConstants.InstructorRoleName)
            {
                await this.instructorsService.DeleteInstructor(userId);
            }
            else if (role == GlobalConstants.AdministratorRoleName)
            {
                await this.administratorsService.DeleteAdministrator(userId);
            }

            return this.RedirectToAction("Index", "Administration");
        }

        public IActionResult ListUsersByRole(string role)
        {
            var users = this.userManager.GetUsersInRoleAsync(role).Result.ToList();
            if (role == GlobalConstants.StudentRoleName)
            {
                return this.View("ListAdminPanelStudents",users);
            }
            else if (role == GlobalConstants.InstructorRoleName)
            {
                return this.View("ListAdminPanelInstructors", users);
            }
            else if (role == GlobalConstants.AdministratorRoleName)
            {
                return this.View("ListAdminPanelAdmins" , users);
            }

            return this.NotFound();
        }
    }
}
