﻿namespace WorldUniversity.Services.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.EntityFrameworkCore;
    using WorldUniversity.Common;
    using WorldUniversity.Data;
    using WorldUniversity.Data.Models;
    using WorldUniversity.Web.ViewModels.Students;

    public class StudentsService : IStudentsService
    {
        private readonly ApplicationDbContext context;
        private readonly UserManager<ApplicationUser> userManager;

        public StudentsService(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            this.context = context;
            this.userManager = userManager;
        }

        public async Task DeleteStudent(string userId)
        {

            var student = await this.userManager.Users.FirstOrDefaultAsync(u => u.Id == userId);
            await this.userManager.RemoveFromRoleAsync(student, GlobalConstants.StudentRoleName);

            var studentEnrollemnts = this.context.Enrollments.Where(s => s.StudentId == userId).ToList();

            if (studentEnrollemnts.Count != 0)
            {
                foreach (var enrollement in studentEnrollemnts)
                {
                    enrollement.IsDeleted = true;
                    enrollement.DeletedOn = DateTime.UtcNow;
                    //enrollement.StudentId = null;
                     this.context.Update(enrollement);
                }

            }
            await this.userManager.DeleteAsync(student);

            await this.context.SaveChangesAsync();
        }

        public ICollection<StudentViewModel> GetAll()
        {
            var role = this.context.Roles.Where(x => x.Name == GlobalConstants.StudentRoleName).FirstOrDefault();

            var student = this.context.Users
            .Include(s => s.Roles)
            .Include(s => s.Enrollments)
            .ThenInclude(e => e.Course)
             .Where(i => i.Roles.Any(x => x.RoleId == role.Id))
            .Select(x => new StudentViewModel
            {
                Id = x.Id,
                FirstName = x.FirstName,
                LastName = x.LastName,
                Username = x.UserName,
                Email = x.Email,
                Enrollments = x.Enrollments,
                IsEmailConfirmed = x.EmailConfirmed,
            })
            .ToList();

            return student;
        }

        public StudentViewModel GetStudentDetails(string id)
        {
            var student = this.context.Users
                .Where(x => x.Id == id)
               .Include(s => s.Enrollments)
               .ThenInclude(e => e.Course)
               .Select(x => new StudentViewModel
               {
                   Id = x.Id,
                   FirstName = x.FirstName,
                   LastName = x.LastName,
                   Email = x.Email,
                   Enrollments = x.Enrollments,
               }
               )
               .FirstOrDefault();
            return student;
        }
        public bool IsEmailInUse(string email)
        {
            return this.context.Users.Any(e => e.Email == email);
        }
        public bool IsUsernameInUse(string username)
        {
            return this.context.Users.Any(e => e.UserName == username);
        }

    }
}
