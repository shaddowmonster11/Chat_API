﻿namespace WorldUniversity.Services.Data
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    using WorldUniversity.Data.Models;
    using WorldUniversity.Web.ViewModels.Instructors;

    public interface IInstructorsService
    {
        ICollection<InstructorViewModel> GetAll();

        ICollection<InstructorRoleDetailsViewModel> GetAllRoleDetails();

        bool IsEmailInUse(string email);

        bool IsUsernameInUse(string username);
        Task DeleteInstructor(string userId);
    }
}
