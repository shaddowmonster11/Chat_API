﻿namespace WorldUniversity.Web.ViewModels.Exams
{
    using System.ComponentModel.DataAnnotations;

    public class AssignedExamData
    {
        public string Id { get; set; }
        [Display(Name = "Title")]
        public string Title { get; set; }
        public bool Assigned { get; set; }
    }
}
