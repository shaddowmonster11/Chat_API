﻿namespace WorldUniversity.Data.Models
{
    using System;
    using System.Collections.Generic;

    using WorldUniversity.Data.Common.Models;

    public class Category: BaseDeletableModel<string>
    {/*TODO READY*/
        public Category()
        {
            this.Courses = new HashSet<Course>();
            this.Id = Guid.NewGuid().ToString();
        }

        public string Title { get; set; }

        public string CategoryDescription { get; set; }

        public virtual ICollection<Course> Courses { get; set; }
    }
}
