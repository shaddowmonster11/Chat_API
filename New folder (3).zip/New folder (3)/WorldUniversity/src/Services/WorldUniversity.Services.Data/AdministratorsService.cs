﻿namespace WorldUniversity.Services.Data
{
    using Microsoft.AspNetCore.Identity;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using WorldUniversity.Common;
    using WorldUniversity.Data;
    using WorldUniversity.Data.Models;

    public class AdministratorsService : IAdministratorsService
    {
        private readonly ApplicationDbContext context;
        private readonly UserManager<ApplicationUser> userManager;

        public AdministratorsService(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            this.context = context;
            this.userManager = userManager;
        }

        public async Task DeleteAdministrator(string userId)
        {
            var admin = await this.userManager.Users.FirstOrDefaultAsync(u => u.Id == userId);
            await this.userManager.RemoveFromRoleAsync(admin, GlobalConstants.AdministratorRoleName);
            await this.userManager.DeleteAsync(admin);
        }
    }
}
