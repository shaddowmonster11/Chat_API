﻿namespace WorldUniversity.Web.ViewModels.Courses
{
    using WorldUniversity.Data.Models;
    using WorldUniversity.Services.Mapping;

    public class CategoryDropDownViewModel: IMapFrom<Category>
    {
        public string Id { get; set; }

        public string Title { get; set; }
    }
}
