﻿namespace WorldUniversity.Web.ViewModels.Categories
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    using WorldUniversity.Data.Models;
    using WorldUniversity.Services.Mapping;

    public class CategoryViewModel : IMapFrom<Category>
    {
        public string Id { get; set; }

        public string Title { get; set; }

        public string CategoryDescription { get; set; }

        public virtual IEnumerable<Course> Courses { get; set; }
    }
}
