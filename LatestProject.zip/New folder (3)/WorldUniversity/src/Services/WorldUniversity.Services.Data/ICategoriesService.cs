﻿namespace WorldUniversity.Services.Data
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    using WorldUniversity.Web.ViewModels.Categories;

    public interface ICategoriesService
    {
        Task CreateAsync(CategoryInputModel input);

        Task UpdateAsync(CategoryUpdateInputModel input);

        Task DeleteAsync(string id);

        Task<T> GetByIdAsync<T>(string id);

        IEnumerable<T> GetAll<T>();
    }
}
