﻿namespace WorldUniversity.Web.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.Security.Claims;
    using System.Threading.Tasks;
    using WorldUniversity.Services.Data.Exams;
    using WorldUniversity.Web.ViewModels.Exams;

    public class ExamSessionsController : Controller
    {
        private readonly IExamsService examsService;


        public ExamSessionsController(
            IExamsService examsService
     )
        {
            this.examsService = examsService;
        }
        public IActionResult Index()
        {
            /*   var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
               var courses = enrollmentsService.GetAllUserCourses(userId);*/
            // return View("Test");
            var exams = examsService.GetAllExams();
            return View(exams);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(string courseId)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (ModelState.IsValid)
            {
                return RedirectToAction(nameof(Index));
            }

            return View();
        }
        public IActionResult ListExams()
        {

            return View();

        }
        public IActionResult Instruction()
        {
            ExamViewModel exam = new ExamViewModel
            {
                Id = "a",
                Description = "hello world",
                DurationInMinutes = 60,
                Title = "new exam"

            };


            return View(exam);

        }


    }
}
