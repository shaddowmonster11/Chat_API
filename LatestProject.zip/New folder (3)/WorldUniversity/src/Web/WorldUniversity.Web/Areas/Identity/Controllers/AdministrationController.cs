﻿namespace WorldUniversity.Web.Areas.Identity.Controllers
{
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Linq;
    using System.Threading.Tasks;
    using WorldUniversity.Common;
    using WorldUniversity.Data.Models;
    using WorldUniversity.Services.Data;
    using WorldUniversity.Web.Infrastructure.Attributes;
    using WorldUniversity.Web.ViewModels.Administration;

    [AuthorizeRoles(new[] { GlobalConstants.AdministratorRoleName })]
    public class AdministrationController : Controller
    {
        private readonly RoleManager<ApplicationRole> roleManager;
        private readonly UserManager<ApplicationUser> userManager;
        private readonly ILogger<AdministrationController> logger;
        private readonly IStudentsService studentsService;
        private readonly IInstructorsService instructorsService;

        public AdministrationController(
            RoleManager<ApplicationRole> roleManager,
            UserManager<ApplicationUser> userManager,
            ILogger<AdministrationController> logger,
            IStudentsService studentsService,
            IInstructorsService instructorsService)
        {
            this.roleManager = roleManager;
            this.userManager = userManager;
            this.logger = logger;
            this.studentsService = studentsService;
            this.instructorsService = instructorsService;
        }

        public IActionResult ListAdminPanelInstructors()
        {
            var users = this.instructorsService.GetAllRoleDetails();
            return this.View(users);
        }

        public IActionResult ListAdminPanelStudents()
        {
            var users = this.studentsService.GetAll();
            return this.View(users);
        }

        public IActionResult ListAdminPanelAdmins()
        {
            var users = this.userManager.GetUsersInRoleAsync(GlobalConstants.AdministratorRoleName).Result.ToList();
            var admins = users
            .Select(x => new AdminRoleDetailsViewModel
            {
                Id = x.Id,
                FirstName = x.FirstName,
                LastName = x.LastName,
                Username = x.UserName,
                Email = x.Email,
            })
            .ToList();
            return this.View(admins);
        }

        public IActionResult UpdateAdminPanelAdmin(string userId)
        {
            var users = this.userManager.GetUsersInRoleAsync(GlobalConstants.AdministratorRoleName).Result.ToList();
            var admin = users.Select(x => new UpdateAdminDetailsViewModel
            {
                Id = x.Id,
                FirstName = x.FirstName,
                LastName = x.LastName,
                IsEmailConfirmed = x.EmailConfirmed,
                Email = x.Email,
                Role = GlobalConstants.AdministratorRoleName,
                Username = x.UserName,
            })
              .FirstOrDefault(x => x.Id == userId);
            return View(admin);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateAdminPanelAdmin(string userId, UpdateAdminDetailsViewModel input)
        {
            var users = this.userManager.GetUsersInRoleAsync(GlobalConstants.AdministratorRoleName).Result.ToList();
            var admin = users.FirstOrDefault(x => x.Id == userId);

            admin.FirstName = input.FirstName;
            admin.LastName = input.LastName;
            admin.Email = input.Email;
            var userRoles = await this.userManager.GetRolesAsync(admin);
            admin.UserName = input.Username;
            admin.EmailConfirmed = input.IsEmailConfirmed;
            switch (input.Role)
            {
                case GlobalConstants.StudentRoleName:
                    await this.userManager.RemoveFromRolesAsync(admin, userRoles);
                    await this.userManager.AddToRoleAsync(admin, GlobalConstants.StudentRoleName);
                    break;
                case GlobalConstants.InstructorRoleName:
                    await this.userManager.RemoveFromRolesAsync(admin, userRoles);
                    await this.userManager.AddToRoleAsync(admin, GlobalConstants.InstructorRoleName);
                    break;
                case GlobalConstants.AdministratorRoleName:
                    await this.userManager.RemoveFromRolesAsync(admin, userRoles);
                    await this.userManager.AddToRoleAsync(admin, GlobalConstants.AdministratorRoleName);
                    break;
            }
            await this.userManager.UpdateAsync(admin);
            return View();
        }


        public IActionResult Index()
        {
            var admins = this.userManager.GetUsersInRoleAsync(GlobalConstants.AdministratorRoleName).Result.ToList();
            var students = this.userManager.GetUsersInRoleAsync(GlobalConstants.StudentRoleName).Result.ToList();
            var instructors = this.userManager.GetUsersInRoleAsync(GlobalConstants.InstructorRoleName).Result.ToList();
            var users = new ListingUsersViewModel
            {
                Administrators = admins,
                Students = students,
                Instructors = instructors,
            };

            return this.View(users);
        }
    }
}
