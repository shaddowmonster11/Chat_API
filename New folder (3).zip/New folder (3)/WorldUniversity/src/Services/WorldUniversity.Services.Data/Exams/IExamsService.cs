﻿namespace WorldUniversity.Services.Data.Exams
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    using WorldUniversity.Web.ViewModels.Exams;

    public interface IExamsService
    {
        Task CreateExam(CreateExamInputModel input);
        ICollection<ExamViewModel> GetAllExams();
        /* ExamViewModel GetExamAllDetails(string id);

         ICollection<ExamViewModel> GetAllUserExams(string userId);
         ExamDetailsViewModel GetExamDetails(string Id);
         Task UpdateExam(ExamDetailsViewModel exam);
         Task ArchieveExam(string id);
         bool ExamExists(string title, DateTime date);
         bool ExamIsArchieved(string title);
         ExamViewModel GetExamById(string id);
         List<AssignedExamData> PopulateAssignedExamData(int courseId,
         ICollection<ExamViewModel> allExams);*/

    }
}
