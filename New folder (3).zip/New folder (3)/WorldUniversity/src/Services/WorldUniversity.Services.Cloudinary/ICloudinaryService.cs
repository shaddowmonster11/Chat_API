﻿namespace WorldUniversity.Services.Cloudinary
{
    public interface ICloudinaryService
    {
        string GetImgByName(string name);
    }
}
