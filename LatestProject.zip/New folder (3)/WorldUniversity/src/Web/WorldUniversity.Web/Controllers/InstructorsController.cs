﻿namespace WorldUniversity.Web.Controllers
{
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.Mvc;
    using WorldUniversity.Common;
    using WorldUniversity.Services.Data;
    using WorldUniversity.Web.Infrastructure.Attributes;
    using WorldUniversity.Web.ViewModels.Instructors;

    [AuthorizeRoles(new[] { GlobalConstants.AdministratorRoleName, GlobalConstants.InstructorRoleName })]
    public class InstructorsController : Controller
    {
        private readonly IInstructorsService instructorsService;

        public InstructorsController(IInstructorsService instructorsService)
        {
            this.instructorsService = instructorsService;
        }

        public IActionResult Index()
        {
            var viewModel = this.instructorsService.GetAll();

            return this.View(viewModel);
        }

        public IActionResult Details(string id)
        {
            /* var instructor = instructorService.GetInstructorsDetails(id);
             return View(instructor);*/
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(InstructorInputModel input)
        {/*
            var isEmailAvaliable = this.instructorsService.IsEmailInUse(input.Email);
            if (!isEmailAvaliable)
            {
                this.ModelState.AddModelError(string.Empty, $"Instructor with email {input.Email} already exist!");
            }

            if (!this.instructorsService.IsUsernameInUse(input.UserName))
            {
                this.ViewBag.ErrorTitle = "Dublicated Username";
                this.ViewBag.ErrorMessage = $"Instructor with {input.UserName} already exists";
                this.ModelState.AddModelError(string.Empty, this.ViewBag.ErrorMesssage);
            }

            if (this.ModelState.IsValid)
            {
                await this.instructorsService.Create(input);
                return RedirectToAction(nameof(Index));
            }*/
            //var allCourses = coursesService.GetAllCourses();
            //var viewModel = instructorService.PopulateAssignedCourseData(instructor, allCourses);
            // ViewData["Courses"] = viewModel;

            return View();
        }

        public IActionResult Edit(string id)
        {
            /*  var courses = coursesService.GetAll();
              var listOfCourses = new List<string>();
              var instructor = instructorService.GetInstructorsDetails(id);
              foreach (var assingment in instructor.CourseAssignments)
              {
                  listOfCourses.Add(assingment.Id);
              }
              instructor.SelectedCoursesId = listOfCourses.ToArray();
              instructor.CourseAssignments = courses;
              return View(instructor);*/
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit()
        {
            /*  await instructorService.UpdateInstructor(
                  instructor.FirstName,
                  instructor.LastName,
                  instructor.SelectedCoursesId,
                  instructor.Id);
              return RedirectToAction("Index", "Instructors", new { id = instructor.Id });*/
            return View();
        }
    }
}