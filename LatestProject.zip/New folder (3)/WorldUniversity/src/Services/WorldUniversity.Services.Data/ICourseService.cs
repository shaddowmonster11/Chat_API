﻿namespace WorldUniversity.Services.Data
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    using WorldUniversity.Web.ViewModels.Courses;

    public interface ICourseService
    {
        Task CreateAsync(CourseInputModel input);

        Task UpdateCourse(int Id, string title, int credits, int? departmentId);

        Task DeleteCourse(string id);

        ICollection<CourseViewModel> GetAllCourses();
    }
}
