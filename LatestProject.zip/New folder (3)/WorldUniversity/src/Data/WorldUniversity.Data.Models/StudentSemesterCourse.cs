﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WorldUniversity.Data.Common.Models;

namespace WorldUniversity.Data.Models
{
    public class StudentSemesterCourse : BaseDeletableModel<string>, IAuditInfo
    {
        public StudentSemesterCourse()
        {
            this.Id = Guid.NewGuid().ToString();
        }

        public string StudentId { get; set; }

        public ApplicationUser Student { get; set; }

        public string SemesterCourseId { get; set; }

        public SemesterCourse SemesterCourse { get; set; }

        public string Grade { get; set; }

        public double Score { get; set; }

        public int Repeats { get; set; }

        public string CreatedBy { get; set; }

        public string UpdatedBy { get; set; }
    }
}
