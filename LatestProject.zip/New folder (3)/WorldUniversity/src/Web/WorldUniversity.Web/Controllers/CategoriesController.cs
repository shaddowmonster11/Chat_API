﻿namespace WorldUniversity.Web.Controllers
{
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using WorldUniversity.Services.Data;
    using WorldUniversity.Web.ViewModels.Categories;

    [Authorize(Roles = "Administrator")]
    public class CategoriesController : Controller
    {
        private readonly ICategoriesService categoriesService;

        public CategoriesController(ICategoriesService categoriesService)
        {
            this.categoriesService = categoriesService;
        }

        public IActionResult Index()
        {
            var categories = this.categoriesService.GetAll<CategoryViewModel>();
            return this.View(categories);
        }

        public IActionResult Create()
        {
            return this.View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CategoryInputModel category)
        {
            if (this.ModelState.IsValid)
            {
                await this.categoriesService.CreateAsync(category);

                return this.RedirectToAction("index", "categories");
            }

            return this.View();
        }

        public async Task<IActionResult> Update(string id)
        {
            var category = await this.categoriesService.GetByIdAsync<CategoryUpdateViewModel>(id);
            if (category == null)
            {
                return this.NotFound();
            }

            var viewModel = new CategoryUpdateInputModel
            {
                Id = category.Id,
                Title = category.Title,
                CategoryDescription = category.CategoryDescription,
            };
            return this.View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(CategoryUpdateInputModel category)
        {
            if (this.ModelState.IsValid)
            {
                await this.categoriesService.UpdateAsync(category);
                return this.RedirectToAction("Index");
            }

            return this.View(category);
        }

        public async Task<IActionResult> Delete(string Id)
        {
            await this.categoriesService.DeleteAsync(Id);

            return this.RedirectToAction("Index");
        }
    }
}
