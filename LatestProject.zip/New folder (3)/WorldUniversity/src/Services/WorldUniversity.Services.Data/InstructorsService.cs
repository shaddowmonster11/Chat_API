﻿namespace WorldUniversity.Services.Data
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.EntityFrameworkCore;
    using WorldUniversity.Common;
    using WorldUniversity.Data;
    using WorldUniversity.Data.Common.Repositories;
    using WorldUniversity.Data.Models;
    using WorldUniversity.Web.ViewModels.Instructors;

    public class InstructorsService : IInstructorsService
    {
        private readonly IDeletableEntityRepository<Category> categoryRepository;
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<ApplicationRole> roleManager;

        public InstructorsService(
          IDeletableEntityRepository<Category> categoryRepository,
            UserManager<ApplicationUser> userManager,
            RoleManager<ApplicationRole> roleManager)
        {
            this.categoryRepository = categoryRepository;
            this.userManager = userManager;
            this.roleManager = roleManager;
        }

        public async Task DeleteInstructor(string userId)
        {
            var instructor = await this.userManager.Users.FirstOrDefaultAsync(u => u.Id == userId);
            await this.userManager.RemoveFromRoleAsync(instructor, GlobalConstants.AdministratorRoleName);
            await this.userManager.DeleteAsync(instructor);
        }

        public ICollection<InstructorViewModel> GetAll()
        {
            var role = this.roleManager.Roles.Where(x => x.Name == GlobalConstants.InstructorRoleName).FirstOrDefault();
            var instructors = this.userManager.Users
             .Include(i => i.Roles)
             .Include(i => i.SemesterCourses)
             .Where(i => i.Roles.Any(x => x.RoleId == role.Id))
             .Select(x => new InstructorViewModel
             {
                 Id = x.Id,
                 FirstName = x.FirstName,
                 LastName = x.LastName,
                 CreatedOn = x.CreatedOn.ToString("G"),
                 Email = x.Email,
                 SemesterCourses = x.SemesterCourse,
             }).ToList();
            return instructors;
        }

        public ICollection<InstructorRoleDetailsViewModel> GetAllRoleDetails()
        {
            var role = this.roleManager.Roles.Where(x => x.Name == GlobalConstants.InstructorRoleName).FirstOrDefault();
            var instructors = this.userManager.Users
             .Include(i => i.Roles)
             .Where(i => i.Roles.Any(x => x.RoleId == role.Id))
             .Select(x => new InstructorRoleDetailsViewModel
             {
                 Id = x.Id,
                 FirstName = x.FirstName,
                 LastName = x.LastName,
                 Username = x.UserName,
                 Email = x.Email,
             }).ToList();
            return instructors;
        }

        public bool IsEmailInUse(string email)
        {
            return this.userManager.Users.Any(x => x.Email == email);
        }

        public bool IsUsernameInUse(string username)
        {
            return this.userManager.Users.Any(x => x.UserName == username);
        }
    }
}
