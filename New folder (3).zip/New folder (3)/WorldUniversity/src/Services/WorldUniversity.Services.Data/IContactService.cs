﻿namespace WorldUniversity.Services.Data
{
    using System.Threading.Tasks;

    public interface IContactService
    {
        Task CreateAsync(string name, string email, string title, string content);
    }
}
