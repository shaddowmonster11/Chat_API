﻿namespace WorldUniversity.Services.Data
{
    using System.Linq;

    using WorldUniversity.Data;
    using WorldUniversity.Web.ViewModels;

    public class HomeService : IHomeService
    {
        private readonly ApplicationDbContext _context;


        public HomeService(ApplicationDbContext context)
        {
            _context = context;
        }
        //public EnrollmentDateGroup GetGeneralInformation()
        //{
        //
        //
        //    
        //    var groups = new EnrollmentDateGroup
        //    {
        //
        //    };
        //    return groups;
        //}
    }
}
