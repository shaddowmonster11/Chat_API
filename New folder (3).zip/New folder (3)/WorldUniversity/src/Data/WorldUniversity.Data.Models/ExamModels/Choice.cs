﻿namespace WorldUniversity.Data.Models.ExamModels
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

   public class Choice
    {
        public Choice()
        {
            this.Id = Guid.NewGuid().ToString();
            ExamPapers = new HashSet<ExamPaper>();
        }
     
        public string Id { get; set; }
        public string QuestionId { get; set; }
        public string Label { get; set; }
        public double Points { get; set; }
        public bool? IsActive { get; set; }
        public  Question Question { get; set; }
        public  ICollection<ExamPaper> ExamPapers { get; set; }
    }
}
